package com.example.egxsignal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/** شموع يومية من TradingView عن طريق WebSocket (غير رسمي). بيرجّع JSON: {"ok":true,"rows":[[t,o,h,l,c,v],...]} أو {"ok":false,"err":"..."} */
final class TvHistory {
    private TvHistory() {}

    private static String frame(String payload) {
        return "~m~" + payload.length() + "~m~" + payload;
    }

    private static void send(WebSocket ws, String name, JSONArray params) throws Exception {
        ws.send(frame(new JSONObject().put("m", name).put("p", params).toString()));
    }

    static String fetch(final String tvSym, final int bars, long timeoutMs) {
        final CountDownLatch done = new CountDownLatch(1);
        final TreeMap<Long, double[]> data = new TreeMap<Long, double[]>();
        final String[] err = {null};
        final String cs = "cs_" + Long.toString(Math.abs(new Random().nextLong()), 36);
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(12, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .build();
        Request req = new Request.Builder()
                .url("wss://data.tradingview.com/socket.io/websocket")
                .header("Origin", "https://www.tradingview.com")
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
                .build();
        WebSocket ws = client.newWebSocket(req, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket w, Response r) {
                try {
                    send(w, "set_auth_token", new JSONArray().put("unauthorized_user_token"));
                    send(w, "chart_create_session", new JSONArray().put(cs).put(""));
                    String sym = "=" + new JSONObject().put("symbol", tvSym).put("adjustment", "splits").toString();
                    send(w, "resolve_symbol", new JSONArray().put(cs).put("sds_sym_1").put(sym));
                    send(w, "create_series", new JSONArray().put(cs).put("sds_1").put("s1").put("sds_sym_1").put("1D").put(bars).put(""));
                } catch (Exception e) {
                    err[0] = "send: " + e.getMessage();
                    done.countDown();
                }
            }

            @Override
            public void onMessage(WebSocket w, String text) {
                int idx = 0;
                while (text.startsWith("~m~", idx)) {
                    int lenEnd = text.indexOf("~m~", idx + 3);
                    if (lenEnd < 0) break;
                    int len;
                    try {
                        len = Integer.parseInt(text.substring(idx + 3, lenEnd));
                    } catch (Exception e) {
                        break;
                    }
                    int start = lenEnd + 3;
                    if (start + len > text.length()) break;
                    String payload = text.substring(start, start + len);
                    idx = start + len;
                    if (payload.startsWith("~h~")) {
                        w.send(frame(payload));
                        continue;
                    }
                    try {
                        JSONObject o = new JSONObject(payload);
                        String m = o.optString("m", "");
                        if (m.equals("timescale_update") || m.equals("du")) {
                            JSONObject d = o.getJSONArray("p").optJSONObject(1);
                            JSONObject s1 = d == null ? null : d.optJSONObject("sds_1");
                            JSONArray arr = s1 == null ? null : s1.optJSONArray("s");
                            if (arr != null) {
                                for (int i = 0; i < arr.length(); i++) {
                                    JSONArray v = arr.getJSONObject(i).getJSONArray("v");
                                    if (v.length() < 5) continue;
                                    data.put(v.getLong(0), new double[]{v.getDouble(1), v.getDouble(2), v.getDouble(3), v.getDouble(4), v.length() > 5 ? v.optDouble(5, 0) : 0});
                                }
                            }
                        } else if (m.equals("series_completed")) {
                            done.countDown();
                        } else if (m.equals("symbol_error") || m.equals("series_error") || m.equals("critical_error")) {
                            err[0] = m + ": " + o.optJSONArray("p");
                            done.countDown();
                        }
                    } catch (Exception ignored) {
                        // رسالة مش JSON (زي session_id): نتجاهلها
                    }
                }
            }

            @Override
            public void onFailure(WebSocket w, Throwable t, Response r) {
                err[0] = "اتصال: " + t.getClass().getSimpleName() + (r != null ? " HTTP " + r.code() : "") + (t.getMessage() != null ? " " + t.getMessage() : "");
                done.countDown();
            }

            @Override
            public void onClosed(WebSocket w, int code, String reason) {
                done.countDown();
            }
        });
        try {
            done.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
        try {
            ws.close(1000, null);
        } catch (Exception ignored) {
        }
        client.dispatcher().executorService().shutdown();
        try {
            JSONObject out = new JSONObject();
            if (data.isEmpty()) {
                out.put("ok", false).put("err", err[0] != null ? err[0] : "مفيش بيانات (انتهى الوقت)");
            } else {
                JSONArray rows = new JSONArray();
                for (Map.Entry<Long, double[]> e : data.entrySet()) {
                    double[] v = e.getValue();
                    rows.put(new JSONArray().put(e.getKey()).put(v[0]).put(v[1]).put(v[2]).put(v[3]).put(v[4]));
                }
                out.put("ok", true).put("rows", rows);
            }
            return out.toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"err\":\"json\"}";
        }
    }
}
