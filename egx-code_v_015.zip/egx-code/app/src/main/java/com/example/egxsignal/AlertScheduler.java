package com.example.egxsignal;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/** بيجدول فحص الوقف والهدف كل ساعة أثناء الجلسة بتوقيت القاهرة (أيام التداول: الأحد للخميس). */
public final class AlertScheduler {
    static final String WORK_NAME = "egx-check";
    // كل ساعة تقريبا أثناء الجلسة: 10:30 و11:30 و12:30 و13:30 و14:15
    private static final int[][] SLOTS = {{10, 30}, {11, 30}, {12, 30}, {13, 30}, {14, 15}};

    private AlertScheduler() {}

    /** المدة (بالمللي ثانية) لحد أقرب ميعاد فحص جاي. */
    static long nextDelayMs(long nowMs) {
        TimeZone tz = TimeZone.getTimeZone("Africa/Cairo");
        for (int d = 0; d < 8; d++) {
            for (int[] s : SLOTS) {
                Calendar c = Calendar.getInstance(tz);
                c.setTimeInMillis(nowMs);
                c.add(Calendar.DAY_OF_YEAR, d);
                c.set(Calendar.HOUR_OF_DAY, s[0]);
                c.set(Calendar.MINUTE, s[1]);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                int dow = c.get(Calendar.DAY_OF_WEEK);
                if (dow == Calendar.FRIDAY || dow == Calendar.SATURDAY) continue;
                if (c.getTimeInMillis() > nowMs + 60000L) return c.getTimeInMillis() - nowMs;
            }
        }
        return TimeUnit.HOURS.toMillis(12);
    }

    /**
     * fromWorker=false (عند فتح التطبيق): KEEP يعني لو فيه فحص مجدول متتلمسش.
     * fromWorker=true (آخر الفحص الحالي): APPEND_OR_REPLACE يعني الفحص الجاي يتحط بعد الحالي.
     */
    static void schedule(Context ctx, boolean fromWorker) {
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(CheckWorker.class)
                .setInitialDelay(nextDelayMs(System.currentTimeMillis()), TimeUnit.MILLISECONDS)
                .setConstraints(new Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build())
                .build();
        WorkManager.getInstance(ctx).enqueueUniqueWork(
                WORK_NAME,
                fromWorker ? ExistingWorkPolicy.APPEND_OR_REPLACE : ExistingWorkPolicy.KEEP,
                req);
    }
}
