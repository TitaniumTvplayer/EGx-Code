package com.example.egxsignal;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 101;
    private static final int REQ_IMPORT = 102;
    private static final int REQ_NOTIF = 103;
    private static final int MAX_IMPORT_BYTES = 2 * 1024 * 1024;

    private WebView web;
    private SharedPreferences prefs;
    private String pendingExport;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(CheckWorker.PREFS, MODE_PRIVATE);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // الصفحة محلية (من assets) وبتكلم APIs خارجية، فبنسمح لها بالطلبات دي
        s.setAllowUniversalAccessFromFileURLs(true);

        // جسر بين الصفحة والنيتف: تنبيهات الوقف/الهدف + تصدير واستيراد الملفات
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, u));
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");

        // فحص الوقف والهدف مرتين في اليوم (لو فيه فحص مجدول أصلا مبنلمسوش)
        AlertScheduler.schedule(this, false);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** بنبعت نص للصفحة كـ string آمن (JSON-escaped). */
    private void callJs(final String fn, final String arg) {
        final String js = "window." + fn + "&&window." + fn + "(" + JSONObject.quote(arg == null ? "" : arg) + ")";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private boolean hasNotifPermission() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    web.evaluateJavascript("window.onNotifStatus&&window.onNotifStatus()", null);
                }
            });
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingExport = null;
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null || pendingExport == null) throw new IllegalStateException();
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                callJs("onNativeMsg", "تم حفظ النسخة الاحتياطية ✓");
            } catch (Exception e) {
                callJs("onNativeMsg", "تعذر حفظ الملف");
            }
            pendingExport = null;
        } else if (requestCode == REQ_IMPORT) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IllegalStateException();
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] tmp = new byte[8192];
                int n;
                while ((n = in.read(tmp)) > 0) {
                    buf.write(tmp, 0, n);
                    if (buf.size() > MAX_IMPORT_BYTES) throw new IllegalStateException("big");
                }
                callJs("onImportText", new String(buf.toByteArray(), StandardCharsets.UTF_8));
            } catch (Exception e) {
                callJs("onNativeMsg", "تعذر قراءة الملف (أو حجمه كبير)");
            }
        }
    }

    /** الدوال اللي الصفحة تقدر تنادي عليها (window.AndroidBridge). */
    public class Bridge {
        /** قايمة JSON: [{"s":"COMI","sl":75,"tp":95}, ...] للأسهم اللي ليها وقف أو هدف. */
        @JavascriptInterface
        public void syncWatch(String json) {
            if (json == null || json.length() > 200000) return;
            prefs.edit().putString("watch", json).apply();
        }

        @JavascriptInterface
        public void requestNotifPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33 && !hasNotifPermission()) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                    } else {
                        web.evaluateJavascript("window.onNotifStatus&&window.onNotifStatus()", null);
                    }
                }
            });
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("perm", hasNotifPermission());
                o.put("last", prefs.getLong("lastCheck", 0));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void exportData(String json, final String name) {
            pendingExport = json;
            final String fileName = (name == null || name.isEmpty()) ? "egx-code-backup.json" : name;
            runOnUiThread(new Runnable() {
                @Override
                @SuppressWarnings("deprecation")
                public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, fileName);
                    startActivityForResult(i, REQ_EXPORT);
                }
            });
        }

        @JavascriptInterface
        public void importData() {
            runOnUiThread(new Runnable() {
                @Override
                @SuppressWarnings("deprecation")
                public void run() {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_IMPORT);
                }
            });
        }
    }
}
