package com.example.egxsignal;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/** بيفحص أسهمي اللي ليها وقف أو هدف، ويبعت إشعار لو السعر كسر الوقف أو وصل الهدف. */
public class CheckWorker extends Worker {
    static final String PREFS = "egx";
    static final String CHANNEL = "egx_alerts";

    public CheckWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    @Override
    public Result doWork() {
        try {
            check();
        } catch (Throwable ignored) {
            // أي خطأ (نت، JSON...) ما يوقفش الجدولة
        }
        AlertScheduler.schedule(getApplicationContext(), true);
        return Result.success();
    }

    private void check() throws Exception {
        Context ctx = getApplicationContext();
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray arr = new JSONArray(sp.getString("watch", "[]"));

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("Africa/Cairo"));
        String today = f.format(new Date());

        // التنبيهات اللي اتبعتت النهارده بس (عشان ما نكررش نفس الإشعار)
        Set<String> sent = new HashSet<>();
        Set<String> old = sp.getStringSet("sent", null);
        if (old != null) {
            for (String k : old) if (k.endsWith(":" + today)) sent.add(k);
        }

        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String sym = o.optString("s", "").replaceAll("[^A-Za-z0-9]", "");
            double sl = o.optDouble("sl", 0), tp = o.optDouble("tp", 0);
            if (sym.isEmpty() || (!(sl > 0) && !(tp > 0))) continue;

            double price = fetchPrice(sym);
            if (Double.isNaN(price) || price <= 0) continue;

            String type = null;
            if (sl > 0 && price <= sl) type = "sl";
            else if (tp > 0 && price >= tp) type = "tp";
            if (type == null) continue;

            String key = sym + ":" + type + ":" + today;
            if (sent.contains(key)) continue;

            if (type.equals("sl")) {
                showAlert(ctx, sym.hashCode(), "⛔ " + sym + " كسر الوقف",
                        "السعر " + fmt(price) + " تحت الوقف اللي سجلته (" + fmt(sl) + ").");
            } else {
                showAlert(ctx, sym.hashCode() + 1, "🎯 " + sym + " وصل الهدف",
                        "السعر " + fmt(price) + " وصل الهدف اللي سجلته (" + fmt(tp) + ").");
            }
            sent.add(key);
        }
        sp.edit().putStringSet("sent", sent).putLong("lastCheck", System.currentTimeMillis()).apply();
    }

    private static String fmt(double v) {
        return String.format(Locale.US, "%.2f", v);
    }

    /** آخر سعر من Yahoo (نفس المصدر اللي التطبيق بيستخدمه). NaN لو فشل. */
    private double fetchPrice(String sym) {
        String[] hosts = {"query1", "query2"};
        for (String h : hosts) {
            HttpURLConnection c = null;
            try {
                URL u = new URL("https://" + h + ".finance.yahoo.com/v8/finance/chart/" + sym + ".CA?range=5d&interval=1d");
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(15000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0");
                if (c.getResponseCode() != 200) continue;
                StringBuilder sb = new StringBuilder();
                try (InputStream in = c.getInputStream();
                     BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                }
                JSONObject meta = new JSONObject(sb.toString())
                        .getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("meta");
                double p = meta.optDouble("regularMarketPrice", Double.NaN);
                if (!Double.isNaN(p)) return p;
            } catch (Exception ignored) {
                // نجرب الهوست التاني
            } finally {
                if (c != null) c.disconnect();
            }
        }
        return Double.NaN;
    }

    private void showAlert(Context ctx, int id, String title, String text) {
        if (Build.VERSION.SDK_INT >= 33
                && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "تنبيهات الأسهم", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(ctx, CHANNEL)
                : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + "\nللمعلومات فقط، مش نصيحة مالية."))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }
}
